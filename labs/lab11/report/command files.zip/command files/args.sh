#!/bin/bash
echo "Вы ввели аргументы:"
for arg in "$@"
do
 echo $arg
done
